//
//  ViewController2.swift
//  setting4
//
//  Created by swuad_31 on 19/08/2020.
//  Copyright © 2020 swuad_31. All rights reserved.
//

import Foundation

class ViewController2: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
  
}
