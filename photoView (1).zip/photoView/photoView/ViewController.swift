//
//  ViewController.swift
//  photoView
//
//  Created by swuad_31 on 19/08/2020.
//  Copyright © 2020 swuad_31. All rights reserved.
//

import UIKit

var photo = [ "사진1.jpg", "사진2.jpg", "사진3.jpg", "사진4.jpg", "사진5.jpg", "사진6.jpg", "사진7.jpg" ]

class ViewController: UIViewController {

    
    @IBOutlet var imgView: UIImageView!
    @IBOutlet var pageControl: UIPageControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        pageControl.numberOfPages = photo.count
        pageControl.currentPage = 0
        
        pageControl.pageIndicatorTintColor = UIColor.green
        
        pageControl.currentPageIndicatorTintColor = UIColor.red
        
        imgView.image = UIImage(named: photo[0])
    }

    
    @IBAction func pageChange(_ sender: UIPageControl) {
        imgView.image = UIImage(named: photo[pageControl.currentPage])
    }
    
}

